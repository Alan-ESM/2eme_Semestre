function checkAnswer(question, correctAnswer) {
    const userAnswer = document.querySelector(`input[name="${question}"]:checked`);
    if (userAnswer && userAnswer.value === correctAnswer) {
        userAnswer.parentElement.style.color = 'green';
    } else if (userAnswer) {
        userAnswer.parentElement.style.color = 'red';
    }
}

function submitQuiz() {
    const totalQuestions = 10; // Ajustez le nombre total de questions
    let score = 0;
    const answers = {
        q1: "b",
        q2: "a",
        q3: "a",
        q4: "a",
        q5: "b",
        q6: "a",
        q7: "a",
        q8: "a",
        q9: "a",
        q10: "a"
    };

    for (let question in answers) {
        const userAnswer = document.querySelector(`input[name="${question}"]:checked`);
        if (userAnswer && userAnswer.value === answers[question]) {
            score++;
        }
    }

    const resultDiv = document.getElementById('result');
    const scorePercentage = (score / totalQuestions) * 100;
    let message = "";

    if (score === totalQuestions) {
        message = "Bravo ! Toutes les réponses sont correctes.";
        resultDiv.style.color = "green";
    } else if (scorePercentage >= 50) {
        message = "Bien joué ! Vous avez plus de 50% de bonnes réponses.";
        resultDiv.style.color = "orange";
    } else {
        message = "Désolé, moins de 50% de bonnes réponses.";
        resultDiv.style.color = "red";
    }

    resultDiv.innerHTML = `Votre score : ${scorePercentage}% - ${message}`;
}