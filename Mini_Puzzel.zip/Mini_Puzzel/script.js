
var time = 0;
// Enregistre le temps écoulé
var pause = true;
// Drapeau indiquant si le jeu est en pause, vrai signifie qu'il est en pause
var set_timer;
// Fonction du minuteur
var d = new Array(10);
// Stocke le numéro du petit DIV actuellement dans le grand DIV
var d_direct = new Array(
  [0],
  [2, 4], // Le grand DIV avec le numéro 1 peut aller aux positions 2 et 4
  [1, 3, 5],
  [2, 6],
  [1, 5, 7],
  [2, 4, 6, 8],
  [3, 5, 9],
  [4, 8],
  [5, 7, 9],
  [6, 8]
);
// Enregistre les positions de déplacement possibles pour les grands DIV
var d_posXY = new Array(
  [0],
  [0, 0], // Le premier nombre représente la gauche, le second représente le haut. Par exemple, la position du premier bloc est gauche:0px, haut:0px
  [150, 0],
  [300, 0],
  [0, 150],
  [150, 150],
  [300, 150],
  [0, 300],
  [150, 300],
  [300, 300]
);
// Position des grands DIV
d[1] = 1;
d[2] = 2;
d[3] = 3;
d[4] = 4;
d[5] = 5;
d[6] = 6;
d[7] = 7;
d[8] = 8;
d[9] = 0;
// Agrangement par défaut, le neuvième grand DIV est vide, donc c'est 0. Nous utilisons 0 pour représenter la tuile vide.
// puzzle.js

function move(id) {
    // Fonction de déplacement
    var i = 1;
    for (i = 1; i < 10; ++i) {
      if (d[i] == id) break;
    }
    // Cette boucle trouve la position du petit DIV dans le grand DIV
    var target_d = 0;
    // Enregistre les positions possibles pour le petit DIV, 0 signifie qu'il ne peut pas bouger
    target_d = whereCanTo(i);
    // Découvre où le petit DIV peut se déplacer. Si elle renvoie 0, cela signifie qu'il ne peut pas bouger, sinon, elle renvoie le numéro de la position cible
    if (target_d != 0) {
      d[i] = 0;
      // Définit le numéro du grand DIV actuel sur 0 car le petit DIV s'est déplacé, donc le grand DIV actuel est maintenant vide
      d[target_d] = id;
      // Définit le grand DIV cible au numéro du petit DIV cliqué
      document.getElementById("d" + id).style.left = d_posXY[target_d][0] + "px";
      document.getElementById("d" + id).style.top = d_posXY[target_d][1] + "px";
      // Enfin, définit la position du petit DIV cliqué sur la position du grand DIV cible
    }
  
    var finish_flag = true;
    // Drapeau indiquant si le jeu est terminé, vrai signifie qu'il est terminé
    for (var k = 1; k < 9; ++k) {
      if (d[k] != k) {
        finish_flag = false;
        break;
      }
    }
    // Itère à partir de 1, vérifie chaque numéro de grand DIV. Si ils ne sont pas dans l'ordre, le jeu n'est pas terminé.
    if (finish_flag == true) {
      if (!pause) start();
      alert("Félicitations!");
    }
    // Si vrai, le jeu est terminé. Si il n'est pas en pause, appelle la fonction de pause et affiche un message de réussite.
  }
  // puzzle.js

function whereCanTo(cur_div) {
    // Fonction pour déterminer si un DIV donné peut se déplacer et vers quelle position
    var j = 0;
    var move_flag = false;
    for (j = 0; j < d_direct[cur_div].length; ++j) {
      if (d[d_direct[cur_div][j]] == 0) {
        move_flag = true;
        break;
      }
    }
    if (move_flag == true) {
      return d_direct[cur_div][j];
    } else {
      return 0;
    }
    // Si elle peut se déplacer, renvoie le numéro de la position cible, sinon renvoie 0
  }
  // puzzle.js

function timer() {
    // Fonction de minuteur, s'exécute toutes les secondes
    time += 1;
    var min = parseInt(time / 60); // Convertit les secondes en minutes
    var sec = time % 60; // Obtient les secondes restantes
    document.getElementById("timer").innerHTML =
      min + " minutes " + sec + " seconds";
  }
  // puzzle.js

function start() {
    // Démarrer ou mettre en pause le jeu
    if (pause) {
      document.getElementById("start").innerHTML = "Pause";
      pause = false;
      set_timer = setInterval(timer, 1000);
    } else {
      document.getElementById("start").innerHTML = "Start";
      pause = true;
      clearInterval(set_timer);
    }
  }
  function reset() {
    // Réinitialiser le jeu
    time = 0;
    random_d();
    if (pause) start();
  }
  // puzzle.js

function random_d() {
    // Mélanger aléatoirement les tuiles
    for (var i = 9; i > 1; --i) {
      var to = parseInt(Math.random() * (i - 1) + 1);
      if (d[i] != 0) {
        document.getElementById("d" + d[i]).style.left = d_posXY[to][0] + "px";
        document.getElementById("d" + d[i]).style.top = d_posXY[to][1] + "px";
      }
      if (d[to] != 0) {
        document.getElementById("d" + d[to]).style.left = d_posXY[i][0] + "px";
        document.getElementById("d" + d[to]).style.top = d_posXY[i][1] + "px";
      }
      var tem = d[to];
      d[to] = d[i];
      d[i] = tem;
    }
  }
  // puzzle.js

// Initialiser le jeu lors du chargement de la page
window.onload = function () {
    reset();
  }
 