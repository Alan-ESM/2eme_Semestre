import sys
import json
import os
import requests
import smtplib
from email.message import EmailMessage

API_KEY = "sk-f1b669792bb34d749bc10ab5d74f9212"
DEEPSEEK_API_URL = "https://api.deepseek.ai/v1/generate"  # exemple, à adapter selon API réelle

def call_deepseek(prenom, age):
    prompt = f"Génère un message personnalisé de 3 à 7 lignes pour une personne nommée {prenom} ayant {age} ans, sur le thème du menu culinaire."
    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json"
    }
    data = {
        "prompt": prompt,
        "max_tokens": 150,
        "temperature": 0.7
    }
    response = requests.post(DEEPSEEK_API_URL, headers=headers, json=data)
    if response.status_code == 200:
        result = response.json()
        # Supposons que la réponse a un champ "text"
        return result.get("text", "").strip()
    else:
        print(f"Erreur API DeepSeek: {response.status_code} {response.text}")
        return "Bonjour! Voici un message personnalisé pour vous."

def send_email(smtp_server, smtp_port, smtp_user, smtp_pass, to_email, subject, body, attachment_path):
    msg = EmailMessage()
    msg["From"] = smtp_user
    msg["To"] = to_email
    msg["Subject"] = subject
    msg.set_content(body)
    
    if attachment_path and os.path.isfile(attachment_path):
        with open(attachment_path, "rb") as f:
            file_data = f.read()
            file_name = os.path.basename(attachment_path)
        msg.add_attachment(file_data, maintype="application", subtype="pdf", filename=file_name)
    
    with smtplib.SMTP_SSL(smtp_server, smtp_port) as smtp:
        smtp.login(smtp_user, smtp_pass)
        smtp.send_message(msg)

def main():
    if len(sys.argv) < 3:
        print("Usage: send_email.py <json_file_path> <temp_folder>")
        sys.exit(1)
    
    json_file = sys.argv[1]
    temp_folder = sys.argv[2]
    
    # Charger les données JSON
    with open(json_file, "r", encoding="utf-8") as f:
        data = json.load(f)
    
    menu_name = data["menu"]
    membres = data["membres"]
    
    # Paramètres SMTP (à modifier selon ton fournisseur)
    SMTP_SERVER = "smtp.gmail.com"
    SMTP_PORT = 465
    SMTP_USER = "ton.email@gmail.com"        # ton email
    SMTP_PASS = "ton_mot_de_passe_app"       # mot de passe d'application
    
    # PDF à joindre (dans temp_folder, doit exister)
    pdf_path = os.path.join(temp_folder, menu_name + ".pdf")
    if not os.path.isfile(pdf_path):
        print(f"Fichier PDF non trouvé : {pdf_path}")
    
    subject = f"Menu hebdomadaire - {menu_name}"
    
    for membre in membres:
        prenom = membre["prenom"]
        age = membre["age"]
        email = membre["email"]
        
        # Appel API DeepSeek pour message personnalisé
        try:
            personalized_msg = call_deepseek(prenom, age)
        except Exception as e:
            print(f"Erreur appel API DeepSeek pour {prenom}: {e}")
            personalized_msg = f"Bonjour {prenom}, voici votre menu personnalisé."
        
        body = f"Bonjour {prenom},\n\n{personalized_msg}\n\nCordialement,\nKmer Délices"
        
        try:
            send_email(SMTP_SERVER, SMTP_PORT, SMTP_USER, SMTP_PASS, email, subject, body, pdf_path)
            print(f"Email envoyé à {email}")
        except Exception as e:
            print(f"Erreur envoi email à {email}: {e}")

if __name__ == "__main__":
    main()
